# Fedora OCR (no-GUI, Super+Z)

A tiny setup to capture a screen region and OCR it to clipboard using Tesseract.
Works on GNOME and KDE. Binds **Super/Win+Z** automatically.

## Quick install
```bash
bash install.sh

